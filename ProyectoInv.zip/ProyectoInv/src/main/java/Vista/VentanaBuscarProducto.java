package Vista;

public class VentanaBuscarProducto extends javax.swing.JFrame {

    public VentanaBuscarProducto() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        btnActualizarCantidadBuscar = new javax.swing.JButton();
        lblCodigoBuscar = new javax.swing.JLabel();
        btnCerrarBuscar = new javax.swing.JButton();
        txtCodigoBuscar = new javax.swing.JTextField();
        lblTitulo = new javax.swing.JLabel();
        lblNombreBuscar = new javax.swing.JLabel();
        txtNombreBuscar = new javax.swing.JTextField();
        lblCategoriaBuscar = new javax.swing.JLabel();
        txtCategoriaBuscar = new javax.swing.JTextField();
        lblPrecioBuscar = new javax.swing.JLabel();
        txtPrecioBuscar = new javax.swing.JTextField();
        lblCantidadBuscar = new javax.swing.JLabel();
        txtActualizarCantidadBuscar = new javax.swing.JTextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        btnActualizarCantidadBuscar.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        btnActualizarCantidadBuscar.setText("Actualizar Cantidad");

        lblCodigoBuscar.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        lblCodigoBuscar.setText("Código");

        btnCerrarBuscar.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        btnCerrarBuscar.setText("Cerrar");

        txtCodigoBuscar.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N

        lblTitulo.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        lblTitulo.setText("Detalle del Producto");

        lblNombreBuscar.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        lblNombreBuscar.setText("Nombre");

        txtNombreBuscar.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N

        lblCategoriaBuscar.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        lblCategoriaBuscar.setText("Categoría");

        txtCategoriaBuscar.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        txtCategoriaBuscar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtCategoriaBuscarActionPerformed(evt);
            }
        });

        lblPrecioBuscar.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        lblPrecioBuscar.setText("Precio");

        txtPrecioBuscar.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N

        lblCantidadBuscar.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        lblCantidadBuscar.setText("Cantidad");

        txtActualizarCantidadBuscar.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(60, 60, 60)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(lblNombreBuscar)
                                    .addComponent(lblCodigoBuscar))
                                .addGap(23, 23, 23)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(txtCodigoBuscar, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(txtNombreBuscar, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(lblCategoriaBuscar)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(txtCategoriaBuscar, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                .addGroup(jPanel1Layout.createSequentialGroup()
                                    .addComponent(lblPrecioBuscar)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(txtPrecioBuscar, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGroup(jPanel1Layout.createSequentialGroup()
                                    .addComponent(lblCantidadBuscar)
                                    .addGap(18, 18, 18)
                                    .addComponent(txtActualizarCantidadBuscar, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(31, 31, 31)
                                .addComponent(btnActualizarCantidadBuscar, javax.swing.GroupLayout.PREFERRED_SIZE, 227, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(64, 64, 64)
                                .addComponent(btnCerrarBuscar, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE))))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(79, 79, 79)
                        .addComponent(lblTitulo)))
                .addContainerGap(47, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(55, 55, 55)
                .addComponent(lblTitulo)
                .addGap(50, 50, 50)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblCodigoBuscar)
                    .addComponent(txtCodigoBuscar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblNombreBuscar)
                    .addComponent(txtNombreBuscar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(20, 20, 20)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblCategoriaBuscar)
                    .addComponent(txtCategoriaBuscar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblPrecioBuscar)
                    .addComponent(txtPrecioBuscar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(21, 21, 21)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblCantidadBuscar)
                    .addComponent(txtActualizarCantidadBuscar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(btnActualizarCantidadBuscar, javax.swing.GroupLayout.PREFERRED_SIZE, 68, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(btnCerrarBuscar, javax.swing.GroupLayout.PREFERRED_SIZE, 67, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(45, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(10, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void txtCategoriaBuscarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtCategoriaBuscarActionPerformed

    }//GEN-LAST:event_txtCategoriaBuscarActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnActualizarCantidadBuscar;
    private javax.swing.JButton btnCerrarBuscar;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JLabel lblCantidadBuscar;
    private javax.swing.JLabel lblCategoriaBuscar;
    private javax.swing.JLabel lblCodigoBuscar;
    private javax.swing.JLabel lblNombreBuscar;
    private javax.swing.JLabel lblPrecioBuscar;
    private javax.swing.JLabel lblTitulo;
    private javax.swing.JTextField txtActualizarCantidadBuscar;
    private javax.swing.JTextField txtCategoriaBuscar;
    private javax.swing.JTextField txtCodigoBuscar;
    private javax.swing.JTextField txtNombreBuscar;
    private javax.swing.JTextField txtPrecioBuscar;
    // End of variables declaration//GEN-END:variables
}
